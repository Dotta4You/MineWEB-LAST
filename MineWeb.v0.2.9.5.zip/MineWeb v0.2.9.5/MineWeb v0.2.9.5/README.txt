README zu Emails:

Damit Emails richtig gesendet werden können, musst du Folgende Schritte befolgen: 

Navigiere zu dem Haupt-MineWeb-Ordner und editiere die datei: ,,send_mail.php''. 
Nun kannst du dort alles Konfigurieren!
Wichtig für Uns bzw. für dich ist, dass du deine Admin-Webmaster Email unter: ,,Webmaster Email'' einträgst.

Du musst vorher auf deinem Server einen mailserver installiert sowie konfiguriert haben!

Falls Es Probleme gibt melde dich bitte auf unserem Discord Server!

-> NICHT MEHR VORHANDEN

-------------------------------------------------------------------------------

README to Emails:

In order for emails to be sent correctly, you must follow the following steps:

Navigate to the main MineWeb folder and edit the file: "send_mail.php".
Now you can configure everything there!
It is important for us or for you that you enter your admin webmaster email under: "Webmaster Email".

You must have installed and configured a mail server on your server beforehand!

If there are any problems, please contact us on our Discord server!

-> DOES NOT EXISTS